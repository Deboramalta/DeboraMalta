
<div align="center">
  
  <a href="https://git.io/typing-svg">
    <img
      src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=500&size=22&pause=1000&color=FF00F6&center=true&vCenter=true&random=false&width=524&lines=%E2%8A%B9+Welcome+to+my+profile!+%CB%99%E1%B5%95%CB%99+%E2%8A%B9+"
      alt="Welcome to my profile"
    >
  </a>
</div>

---

<h2 align="center"> 
<h2 align="center">
  <img src="./megif.gif" alt="Meu GIF" width="45" align="center">
  Débora Malta
</h2>


<p align="center">
  <strong>💻 Desenvolvedora Full Stack em formação</strong>
</p>

<p align="center">
  Olá! Seja bem-vindo(a) ao meu GitHub! 👋
</p>

<p align="center">
  Sou estudante de <strong>Análise e Desenvolvimento de Sistemas</strong> e estou em constante aprendizado.
</p>

<p align="center">
  Tenho interesse em explorar novas tecnologias, compreender como os sistemas funcionam e transformar conhecimento em projetos práticos.
</p>

<p align="center">
  Aqui você encontrará projetos desenvolvidos ao longo da minha formação acadêmica, com foco em organização, aprendizado e evolução técnica.
</p>

<p align="center">
  🚀 <em>Aprender tecnologia é um processo contínuo de descobertas e evolução!</em>
</p>

---
<p align="left">  <img src="https://raw.githubusercontent.com/Deboramalta/Deboramalta/main/study.gif"  align="right" alt="" height="200px" "></p>


<h3 align="left">Connect with me!</h3>

<a href="mailto:debora.nasciimeentoo@hotmail.com">
  <img src="https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=FF00F6&color=000" alt="Email">
</a>

<a href="https://www.linkedin.com/in/debora-cristina-malta/">
  <img src="https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=FF00F6&color=000" alt="LinkedIn">
</a>

<a href="https://www.instagram.com/debora.nasciimeentoo/">
  <img src="https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=FF00F6&color=000" alt="Instagram">
</a>

<br clear="both">

---

<h3 align="left">🚀 My Stack</h3>

<div align="left">

  <!-- Front-end -->
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" height="25" alt="HTML5">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" height="25" alt="CSS3">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" height="25" alt="JavaScript">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" height="25" alt="React">

  <!-- Back-end -->
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" height="25" alt="Java">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/spring/spring-original.svg" height="25" alt="Spring">

  <!-- Banco de dados -->
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" height="25" alt="MySQL">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" height="25" alt="PostgreSQL">

</div>

---

<p align="center">
  <picture>
    <source
      media="(prefers-color-scheme: dark)"
      srcset="https://raw.githubusercontent.com/Deboramalta/Deboramalta/output/github-contribution-grid-snake-dark.svg"
    >
    <source
      media="(prefers-color-scheme: light)"
      srcset="https://raw.githubusercontent.com/Deboramalta/Deboramalta/output/github-contribution-grid-snake.svg"
    >
    <img
      alt="github contribution grid snake animation"
      src="https://raw.githubusercontent.com/Deboramalta/Deboramalta/output/github-contribution-grid-snake.svg"
    >
  </picture>
</p>
